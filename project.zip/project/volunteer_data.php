<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "test_2";

if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{

	die("failed to connect!");
}


